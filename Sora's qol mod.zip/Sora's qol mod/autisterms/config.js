import { @Vigilant, @NumberProperty, @SwitchProperty, @SelectorProperty, @DecimalSliderProperty } from "../Vigilance";

@Vigilant("autisterms", "AutisTerms", {
	getCategoryComparator: () => (a, b) => {
		const categories = ["AutoTerms", "Extras"];
		return categories.indexOf(a.name) - categories.indexOf(b.name);
	}
})
class Settings {
	@SwitchProperty({
		name: "Toggle",
		description: "Toggle AutoTerms",
		category: "AutoTerms"
	})
	enabled = false;

	@NumberProperty({
		name: "First Click Delay",
		description: "Delay to apply right after opening a Terminal",
		category: "AutoTerms",
		min: 0,
		max: 2147483647,
		increment: 10
	})
	firstDelay = 350;

	@NumberProperty({
		name: "Click Delay",
		description: "Minimum delay to apply between clicks",
		category: "AutoTerms",
		min: 0,
		max: 2147483647,
		increment: 10
	})
	delay = 190;

	@NumberProperty({
		name: "Timeout",
		description: "Timeout to resync",
		category: "AutoTerms",
		min: 0,
		max: 2147483647,
		increment: 100
	})
	timeout = 500;

	@SwitchProperty({
		name: "Click On Tick",
		description: "Clicks on ticks, safer on lower ping\nCan make AutoTerms significantly slower on high ping\nThis will attempt to average to the specified delay",
		category: "AutoTerms"
	})
	clickOnTick = true;

	@SwitchProperty({
		name: "Not P3",
		description: "Activate AutoTerms even if not in P3, not recommended",
		category: "AutoTerms"
	})
	notP3 = false;

	@SwitchProperty({
		name: "Toggle",
		description: "Enabled AutoTerms for the Numbers Terminal",
		category: "AutoTerms",
		subcategory: "Numbers"
	})
	numbersEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		description: "Enabled AutoTerms for the Colors Terminal",
		category: "AutoTerms",
		subcategory: "Colors"
	})
	colorsEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		description: "Enabled AutoTerms for the Starts With Terminal",
		category: "AutoTerms",
		subcategory: "Starts With"
	})
	startswithEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		description: "Enabled AutoTerms for the Rubix Terminal",
		category: "AutoTerms",
		subcategory: "Rubix"
	})
	rubixEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		description: "Enabled AutoTerms for the Red Green Terminal",
		category: "AutoTerms",
		subcategory: "Red Green"
	})
	redgreenEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		description: "Enabled AutoTerms for the Melody Terminal",
		category: "AutoTerms",
		subcategory: "Melody"
	})
	melodyEnabled = true;

	@SelectorProperty({
		name: "Skip On",
		description: "When to skip",
		options: ["None", "Edges", "All"],
		category: "AutoTerms",
		subcategory: "Melody"
	})
	melodySkip = 1;

	@NumberProperty({
		name: "Skip Delay",
		description: "Delay to skip with",
		category: "AutoTerms",
		subcategory: "Melody",
		min: 0,
		max: 2147483647,
		increment: 10
	})
	melodySkipDelay = 50;

	@NumberProperty({
		name: "Melody First Click Delay",
		description: "Delay to apply right after opening",
		category: "AutoTerms",
		subcategory: "Melody",
		min: 0,
		max: 2147483647,
		increment: 10
	})
	melodyFirstDelay = 0;

	@SwitchProperty({
		name: "Toggle",
		description: "InvWalk on Terminals with window ids",
		category: "Extras",
		subcategory: "InvWalk"
	})
	invWalkEnabled = false;

	@SwitchProperty({
		name: "Melody",
		description: "Enable Melody InvWalk",
		category: "Extras",
		subcategory: "InvWalk"
	})
	invWalkMelody = false;

	@SelectorProperty({
		name: "Melody InvWalk Method",
		description: "How to InvWalk in Melody",
		options: ["Keybind", "Blink"],
		category: "Extras",
		subcategory: "InvWalk"
	})
	invwalkMelodyMethod = 1;

	@NumberProperty({
		name: "Melody Move Delay",
		description: "Time to stop moving for after clicking in Melody",
		category: "Extras",
		subcategory: "InvWalk",
		min: 0,
		max: 2147483647,
		increment: 10
	})
	invWalkMelodyMoveDelay = 300;

	@SwitchProperty({
		name: "Toggle",
		description: "Automatically open Terminals",
		category: "Extras",
		subcategory: "Aura"
	})
	auraEnabled = false;

	@DecimalSliderProperty({
		name: "Distance",
		category: "Extras",
		subcategory: "Aura",
		minF: 0,
		maxF: 5
	})
	auraDistance = 3;

	constructor() {
		this.initialize(this);
	}
}

export default new Settings();
