/// <reference types="../CTAutocomplete" />

import "./vgp";
import Settings from "./config";
import "./terminals/numbers";
import "./terminals/colors";
import "./terminals/startswith";
import "./terminals/rubix";
import "./terminals/redgreen";
import "./terminals/melody";
import "./features/aura";
import "./features/prevent";

register("command", Settings.openGUI).setName("autisterms").setAliases("autoterms");
