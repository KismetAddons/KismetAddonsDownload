import Async from "../../Async";
import Settings from "../config";
import packetOpenWindow from "../events/packetOpenWindow";
import packetSetSlot from "../events/packetSetSlot";
import closeWindow from "../events/closeWindow";
import packetChat from "../events/packetChat";

const C0EPacketClickWindow = Java.type("net.minecraft.network.play.client.C0EPacketClickWindow");

let inP3 = false;
let inTerminal = false;
let isNewTerminal = false;
let cwid = -1;
const slots = [];
let lastClick = 0;
let clicked = false;
let windowSize = 0;
let progress = [0, 0];
let processed = false;

register("renderOverlay", () => {
	if (!inTerminal || !Settings.invWalkEnabled) return;
	let text = "§5IN TERMINAL";
	text += " §2(Rubix)";
	text += " §9[" + progress[0] + "/" + progress[1] + "]";
	const scale = 2;
	Renderer.scale(scale);
	Renderer.drawStringWithShadow(text, (Renderer.screen.getWidth() / scale - Renderer.getStringWidth(text)) / 2, Renderer.screen.getHeight() / scale / 2 + 16);
});

packetChat.addListener(message => {
	if (message === "[BOSS] Goldor: Who dares trespass into my domain?") inP3 = true;
	else if (message === "The Core entrance is opening!") inP3 = false;
});

register("worldUnload", () => {
	inP3 = false;
});

packetOpenWindow.addListener((title, windowId, _0, slotCount, _1, _2, _3, event) => {
	cwid = windowId;
	const rubixMatch = title.match(/^Change all to same color!$/);
	if (rubixMatch !== null) {
		if (!Settings.enabled || !Settings.rubixEnabled || (!inP3 && !Settings.notP3)) return;
		inTerminal = true;
		while (slots.length) slots.pop();
		windowSize = slotCount;
		if (clicked) isNewTerminal = false;
		else isNewTerminal = true;
		clicked = false;
		processed = false;
		if (Settings.invWalkEnabled) cancel(event);
	} else {
		inTerminal = false;
	}
});

closeWindow.addListener(() => {
	inTerminal = false;
	clicked = false;
});

packetSetSlot.addListener((itemStack, slot) => {
	if (!inTerminal) return;
	if (slot < 0) return;
	if (slot >= windowSize) return;
	if (itemStack?.func_77973_b()) {
		const item = new Item(itemStack);
		slots[slot] = {
			slot,
			id: item.getID(),
			meta: item.getMetadata(),
			size: item.getStackSize(),
			name: ChatLib.removeFormatting(item.getName()),
			enchanted: item.isEnchanted()
		};
	} else {
		slots[slot] = null;
	}
	if (slots.filter(slot => slot).length === windowSize) {
		if (processed) return;
		processed = true;
		const initialWindowId = cwid;
		if (isNewTerminal) {
			Async.schedule(() => inTerminal && cwid === initialWindowId && solve(), Settings.firstDelay);
			progress[0] = 0;
			progress[1] = getSolution().length;
		} else {
			const calculatedDelay = Settings.delay - (new Date().getTime() - lastClick);
			if (calculatedDelay <= 0) {
				solve();
			} else {
				Async.schedule(() => inTerminal && cwid === initialWindowId && solve(), calculatedDelay);
			}
			progress[0] = progress[1] - getSolution().length;
		}
	}
});

function solve() {
	const s = getSolution()[0];
	const solution = s?.[0];
	const button = s?.[1];
	if (solution === undefined || button === undefined) return;
	click(solution, button);
}

function getSolution() {
	const solution = [];
	const allowedSlots = [12, 13, 14, 21, 22, 23, 30, 31, 32];
	const order = [14, 1, 4, 13, 11];
	const calcIndex = index => (index + order.length) % order.length;
	const clicks = [0, 0, 0, 0, 0];
	for (let i = 0; i < 5; ++i) {
		slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.meta !== order[calcIndex(i)]).forEach(slot => {
			if (slot.meta === order[calcIndex(i - 2)]) clicks[i] += 2;
			else if (slot.meta === order[calcIndex(i - 1)]) clicks[i] += 1;
			else if (slot.meta === order[calcIndex(i + 1)]) clicks[i] += 1;
			else if (slot.meta === order[calcIndex(i + 2)]) clicks[i] += 2;
		});
	}
	const origin = clicks.indexOf(Math.min(...clicks));
	slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.meta !== order[calcIndex(origin)]).forEach(slot => {
		if (slot.meta === order[calcIndex(origin - 2)]) solution.push([slot.slot, 0], [slot.slot, 0]);
		else if (slot.meta === order[calcIndex(origin - 1)]) solution.push([slot.slot, 0]);
		else if (slot.meta === order[calcIndex(origin + 1)]) solution.push([slot.slot, 1]);
		else if (slot.meta === order[calcIndex(origin + 2)]) solution.push([slot.slot, 1], [slot.slot, 1]);
	});
	return solution;
}

function click(slot, button) {
	if (slot === undefined || button === undefined) return;
	clicked = true;
	lastClick = new Date().getTime();
	const exec = () => Client.sendPacket(new C0EPacketClickWindow(cwid, slot, button, 0, null, 0));
	Settings.clickOnTick ? Client.scheduleTask(0, exec) : exec();
	const initialWindowId = cwid;
	Async.schedule(() => inTerminal && initialWindowId === cwid && solve(), Settings.timeout);
}
