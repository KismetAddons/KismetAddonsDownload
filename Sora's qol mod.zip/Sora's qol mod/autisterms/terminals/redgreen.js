import Async from "../../Async";
import Settings from "../config";
import packetOpenWindow from "../events/packetOpenWindow";
import packetSetSlot from "../events/packetSetSlot";
import closeWindow from "../events/closeWindow";
import packetChat from "../events/packetChat";

const C0EPacketClickWindow = Java.type("net.minecraft.network.play.client.C0EPacketClickWindow");

let inP3 = false;
let inTerminal = false;
let isNewTerminal = false;
let cwid = -1;
const slots = [];
let lastClick = 0;
let clicked = false;
let windowSize = 0;
let progress = [0, 0];
let processed = false;

register("renderOverlay", () => {
	if (!inTerminal || !Settings.invWalkEnabled) return;
	let text = "§5IN TERMINAL";
	text += " §2(Red Green)";
	text += " §9[" + progress[0] + "/" + progress[1] + "]";
	const scale = 2;
	Renderer.scale(scale);
	Renderer.drawStringWithShadow(text, (Renderer.screen.getWidth() / scale - Renderer.getStringWidth(text)) / 2, Renderer.screen.getHeight() / scale / 2 + 16);
});

packetChat.addListener(message => {
	if (message === "[BOSS] Goldor: Who dares trespass into my domain?") inP3 = true;
	else if (message === "The Core entrance is opening!") inP3 = false;
});

register("worldUnload", () => {
	inP3 = false;
});

packetOpenWindow.addListener((title, windowId, _0, slotCount, _1, _2, _3, event) => {
	cwid = windowId;
	const redgreenMatch = title.match(/^Correct all the panes!$/);
	if (redgreenMatch !== null) {
		if (!Settings.enabled || !Settings.redgreenEnabled || (!inP3 && !Settings.notP3)) return;
		inTerminal = true;
		while (slots.length) slots.pop();
		windowSize = slotCount;
		if (clicked) isNewTerminal = false;
		else isNewTerminal = true;
		clicked = false;
		processed = false;
		if (Settings.invWalkEnabled) cancel(event);
	} else {
		inTerminal = false;
	}
});

closeWindow.addListener(() => {
	inTerminal = false;
	clicked = false;
});

packetSetSlot.addListener((itemStack, slot) => {
	if (!inTerminal) return;
	if (slot < 0) return;
	if (slot >= windowSize) return;
	if (itemStack?.func_77973_b()) {
		const item = new Item(itemStack);
		slots[slot] = {
			slot,
			id: item.getID(),
			meta: item.getMetadata(),
			size: item.getStackSize(),
			name: ChatLib.removeFormatting(item.getName()),
			enchanted: item.isEnchanted()
		};
	} else {
		slots[slot] = null;
	}
	if (slots.filter(slot => slot).length === windowSize) {
		if (processed) return;
		processed = true;
		const initialWindowId = cwid;
		if (isNewTerminal) {
			Async.schedule(() => inTerminal && cwid === initialWindowId && solve(), Settings.firstDelay);
			progress[0] = 0;
			progress[1] = getSolution().length;
		} else {
			const calculatedDelay = Settings.delay - (new Date().getTime() - lastClick);
			if (calculatedDelay <= 0) {
				solve();
			} else {
				Async.schedule(() => inTerminal && cwid === initialWindowId && solve(), calculatedDelay);
			}
			progress[0] = progress[1] - getSolution().length;
		}
	}
});

function solve() {
	const solution = getSolution()[0];
	if (solution === undefined) return;
	click(solution, 0);
}

function getSolution() {
	const allowedSlots = [11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 29, 30, 31, 32, 33];
	return slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.id === 160 && slot.meta === 14).map(slot => slot.slot);
}

function click(slot, button) {
	if (slot === undefined || button === undefined) return;
	clicked = true;
	lastClick = new Date().getTime();
	const exec = () => Client.sendPacket(new C0EPacketClickWindow(cwid, slot, button, 0, null, 0));
	Settings.clickOnTick ? Client.scheduleTask(0, exec) : exec();
	const initialWindowId = cwid;
	Async.schedule(() => inTerminal && initialWindowId === cwid && solve(), Settings.timeout);
}
