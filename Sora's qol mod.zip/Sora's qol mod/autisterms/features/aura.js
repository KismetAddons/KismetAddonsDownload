/// <reference types="../../CTAutocomplete" />

import Settings from "../config";
import Vector3 from "../../BloomCore/utils/Vector3";
import packetChat from "../events/packetChat";
import packetOpenWindow from "../events/packetOpenWindow";
import closeWindow from "../events/closeWindow";
import playerPosition from "../events/playerPosition";

const Vec3 = Java.type("net.minecraft.util.Vec3");
const C02PacketUseEntity = Java.type("net.minecraft.network.play.client.C02PacketUseEntity");
const EntityArmorStand = Java.type("net.minecraft.entity.item.EntityArmorStand");

let inTerminal = false;
let lastClick = 0;
let inP3 = false;
const position = [null, null, null];

packetChat.addListener(message => {
	if (message === "[BOSS] Goldor: Who dares trespass into my domain?") inP3 = true;
	else if (message === "The Core entrance is opening!") inP3 = false;
});

packetOpenWindow.addListener(() => {
	inTerminal = true;
});

closeWindow.addListener(() => {
	inTerminal = false;
});

playerPosition.addListener((x, y, z) => {
	position[0] = x;
	position[1] = y;
	position[2] = z;
});

register("tick", () => {
	if (!Settings.auraEnabled) return;
	if (!inP3 && !Settings.notP3) return;
	if (inTerminal) return;
	if (new Date().getTime() - lastClick < 750) return;
	if (position.includes(null)) return;
	const entities = World.getAllEntitiesOfType(EntityArmorStand);
	for (let entity of entities) {
		let isInactiveTerminal = entity.getName() === "§cInactive Terminal";
		if (!isInactiveTerminal) continue;
		let terminalPosition = new Vector3(entity.getX(), entity.getY(), entity.getZ());
		let playerPosition = new Vector3(position[0], position[1], position[2]);
		if (terminalPosition.y + 1 > playerPosition.y) continue;
		let difference = terminalPosition.subtract(playerPosition);
		let isInDistance = difference.getLength() < Settings.auraDistance;
		if (!isInDistance) continue;
		Client.sendPacket(new C02PacketUseEntity(entity.entity, new Vec3(0, 2.075000025331974, 0)));
		lastClick = new Date().getTime();
		break;
	}
});

