import Settings from "../config";
import packetChat from "../events/packetChat";
import packetOpenWindow from "../events/packetOpenWindow";
import closeWindow from "../events/closeWindow";

const C02PacketUseEntity = Java.type("net.minecraft.network.play.client.C02PacketUseEntity");

let lastClick = 0;
let inTerminal = false;
let inP3 = false;

packetChat.addListener(message => {
	if (message === "[BOSS] Goldor: Who dares trespass into my domain?") inP3 = true;
	else if (message === "The Core entrance is opening!") inP3 = false;
});

packetOpenWindow.addListener(() => {
	inTerminal = true;
});

closeWindow.addListener(() => {
	inTerminal = false;
});

register("packetSent", (packet, event) => {
	if (!inP3 && !Settings.notP3) return;
	const entity = new Entity(packet.func_149564_a(World.getWorld()));
	if (entity.getName() !== "§cInactive Terminal") return;
	const time = new Date().getTime();
	if (!inTerminal && lastClick + 500 < time) {
		lastClick = time;
		return;
	}
	if (Settings.debug) ChatLib.chat("prevent " + lastClick + " " + time);
	cancel(event);
}).setFilteredClass(C02PacketUseEntity);
