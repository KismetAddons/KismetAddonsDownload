// Borrowed from Gekke

import { chat } from "./utils"
import { walk } from "./AutoP3Utils"

const termNames = [
    /^Click in order!$/,
    /^Select all the (.+?) items!$/,
    /^What starts with: '(.+?)'\?$/,
    /^Change all to same color!$/,
    /^Correct all the panes!$/,
    /^Click the button on time!$/
]

let inTerminal = false
let S2EPacketCloseWindow = S2EPacketCloseWindow = Java.type("net.minecraft.network.play.server.S2EPacketCloseWindow")
let C0DPacketCloseWindow = C0DPacketCloseWindow = Java.type("net.minecraft.network.play.client.C0DPacketCloseWindow")
let S2DPacketOpenWindow = S2DPacketOpenWindow = Java.type("net.minecraft.network.play.server.S2DPacketOpenWindow")

export const startTermWait = () => {
    listener.register()
    chat("Listening for terminal open.")
}

const listener = register("tick", () => {
    if (!inTerminal) return
    chat("Terminal opened, unregistered.")
    listener.unregister()
    walk()
}).unregister()

// Terminal open and close listener
register("packetReceived", (packet, event) => {
    const windowName = packet.func_179840_c().func_150254_d().removeFormatting()
    if (termNames.some(regex => windowName.match(regex))) inTerminal = true
    else inTerminal = false
}).setFilteredClass(S2DPacketOpenWindow)

register("packetReceived", () => {
    inTerminal = false
}).setFilteredClass(S2EPacketCloseWindow)

register("packetSent", () => {
    inTerminal = false
}).setFilteredClass(C0DPacketCloseWindow)

register("worldLoad", () => {
    inTerminal = false
    listener.unregister()
})

register("command", () => {
    inTerminal = true
    Client.scheduleTask(10, () => {
    if (inTerminal) inTerminal = false
})
}).setName("awt")

